Put static assets (audio/images) here.
